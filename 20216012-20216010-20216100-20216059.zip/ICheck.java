public interface ICheck {
    public boolean checkCost(String courseID);
    public boolean checkScore(String courseID);
}
public class Helpdesk {
    public Helpdesk(){
        System.out.println("Welcome to Questions zone\n");
    }
}
